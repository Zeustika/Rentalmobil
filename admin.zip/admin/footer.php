<footer class="footer mt-5">
      <div class="container">
        <div class="row">
          <div class="col-12 text-center">
            <p class="mb-0">Copyright &copy; <?= date('Y');?> <?= $info_web->nama_rental;?> All Rights Reserved</p>
          </div>
        </div>
      </div>
    </footer>
    <script src="<?php echo $url;?>assets/js/jquery-3.3.1.min.js"></script>
    <script src="<?php echo $url;?>assets/js/bootstrap.min.js"></script>
  </body>
</html>